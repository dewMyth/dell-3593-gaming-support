ThrottleStop 9.2
August 10, 2020

New Features
- added access to the default Windows power options.
- restored Windows 7 compatibility.
- fixed C0% showing 0.0 for all threads on some CPUs.

ThrottleStop 9.1
July 29, 2020

New Features
- updated TS Bench test with random MHz option.
- fixed BCLK MHz reporting when using Core Isolation.
- added support for devices that use connected standby.
- added reporting of suspend / resume times to the log file.
- removed auto BCLK updates when resuming.
- fixed GDI handle leak.
- new color and font options.
- new black notification area icon option.
- new option to remove the title bar.
- removed PROCHOT indicator box.

Kevin Glynn
throttlestop@shaw.ca
